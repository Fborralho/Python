#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 14 09:08:18 2018

@author: kruddy
"""

def sort_by_f(l):
    result = sorted(l, key = lambda x: 5 - x if x >= 5 else x)
    return result



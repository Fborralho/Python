#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 14 09:27:37 2018

@author: kruddy
"""

def odd_range(start, stop, step):
    if start % 2 == 0:
        start += 1 
    while start <= stop:
        yield start
        start += step * 2
    



            